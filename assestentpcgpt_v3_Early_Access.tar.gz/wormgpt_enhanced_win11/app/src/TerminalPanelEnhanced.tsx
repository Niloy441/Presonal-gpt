// ─── ENHANCED TerminalPanel Component ─────────────────────────────────────────
// Features: Process multiplexing, system monitoring, file explorer, analytics
// Add this to App.tsx after the existing TerminalPanel component

const TerminalPanelEnhanced = ({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) => {
  const [lines, setLines] = useState<{ text: string; type: 'in' | 'out' | 'err' | 'sys'; processId?: string }[]>([
    { text: 'WormGPT Terminal Enhanced — Connect backend for real commands', type: 'sys' }
  ]);
  const [input, setInput] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [histIdx, setHistIdx] = useState(-1);
  const [isRunning, setIsRunning] = useState(false);
  const [ws, setWs] = useState<WebSocket | null>(null);
  const [activeTab, setActiveTab] = useState<'terminal' | 'processes' | 'system' | 'files' | 'analytics'>('terminal');
  const [processes, setProcesses] = useState<any[]>([]);
  const [systemStats, setSystemStats] = useState<any>(null);
  const [fileExplorer, setFileExplorer] = useState<any>(null);
  const [analytics, setAnalytics] = useState<any>(null);
  const [currentPath, setCurrentPath] = useState(process.env.HOME || '/home');
  const endRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [lines]);

  // WebSocket connection & message handling
  useEffect(() => {
    if (!isOpen) return;
    try {
      const socket = new WebSocket(window.location.origin.replace(/^http/, 'ws'));
      socket.onopen = () => {
        setLines(p => [...p, { text: '✓ Connected to WormGPT backend server', type: 'sys' }]);
        // Fetch initial stats
        socket.send(JSON.stringify({ type: 'system_stats' }));
        socket.send(JSON.stringify({ type: 'list_processes' }));
      };

      socket.onmessage = (e) => {
        try {
          const d = JSON.parse(e.data);
          
          if (d.type === 'stdout') {
            setLines(p => [...p, { text: d.data, type: 'out', processId: d.processId }]);
          } else if (d.type === 'stderr') {
            setLines(p => [...p, { text: d.data, type: 'err', processId: d.processId }]);
          } else if (d.type === 'exit') {
            setIsRunning(false);
            setLines(p => [...p, {
              text: `[Process exited: ${d.code}]${d.analysis?.errors?.length ? ' ⚠ Errors detected' : ''}`,
              type: d.code === 0 ? 'sys' : 'err',
              processId: d.processId
            }]);
            if (d.analysis?.errors?.length) {
              d.analysis.errors.forEach((err: string) => {
                setLines(p => [...p, { text: `  ERROR: ${err}`, type: 'err' }]);
              });
            }
          } else if (d.type === 'system_stats') {
            setSystemStats(d.data);
          } else if (d.type === 'processes') {
            setProcesses(d.data);
          } else if (d.type === 'process_killed') {
            setLines(p => [...p, { text: `[Process ${d.processId} killed]`, type: 'sys' }]);
          }
        } catch (err) {
          console.error('Parse error:', err);
        }
      };

      socket.onerror = () => {
        setLines(p => [...p, { text: '⚠ Backend offline — run: cd server && npm install && npm start', type: 'err' }]);
      };

      setWs(socket);
      return () => socket.close();
    } catch (err) {
      setLines(p => [...p, { text: '⚠ Could not connect to WebSocket', type: 'err' }]);
    }
  }, [isOpen]);

  // Run shell command
  const runCommand = () => {
    if (!input.trim() || isRunning) return;
    const cmd = input.trim();
    setHistory(p => [cmd, ...p]);
    setHistIdx(-1);
    setLines(p => [...p, { text: `$ ${cmd}`, type: 'in' }]);
    setInput('');
    setIsRunning(true);

    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'shell', command: cmd, cwd: currentPath }));
    } else {
      setTimeout(() => {
        setLines(p => [...p, { text: 'No backend. Start: cd server && npm start', type: 'err' }]);
        setIsRunning(false);
      }, 300);
    }
  };

  // Fetch system stats
  const fetchStats = () => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'system_stats' }));
      ws.send(JSON.stringify({ type: 'list_processes' }));
      
      // Also fetch analytics from REST API
      fetch(`${window.location.origin}/api/analytics`)
        .then(r => r.json())
        .then(setAnalytics)
        .catch(console.error);
    }
  };

  // Fetch file explorer
  const fetchExplorer = async (path: string) => {
    try {
      const res = await fetch(`${window.location.origin}/api/fs/explore?path=${encodeURIComponent(path)}&depth=1`);
      const data = await res.json();
      setFileExplorer(data);
      setCurrentPath(path);
    } catch (err) {
      setLines(p => [...p, { text: `Error exploring ${path}: ${(err as any).message}`, type: 'err' }]);
    }
  };

  // Kill process
  const killProcess = (processId: string) => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'kill', processId }));
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 backdrop-blur-sm">
      <div className="bg-gray-950 border border-red-500/30 rounded-xl w-full max-w-6xl h-[90vh] flex flex-col shadow-2xl animate-scaleIn">
        
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-red-500/20 bg-gray-900 rounded-t-xl">
          <div className="flex items-center gap-3">
            <div className="flex gap-1.5">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <div className="w-3 h-3 rounded-full bg-yellow-500" />
              <div className="w-3 h-3 rounded-full bg-green-500" />
            </div>
            <Terminal size={14} className="text-red-400" />
            <span className="text-sm text-white font-mono font-semibold">WormGPT Terminal Enhanced</span>
          </div>
          <div className="flex gap-2">
            <button onClick={() => fetchStats()} className="text-xs text-red-400/60 hover:text-red-400 px-2 py-1 rounded hover:bg-red-500/20 flex items-center gap-1">
              <RefreshCw size={12} /> Refresh
            </button>
            <button onClick={() => setLines([{ text: 'Cleared.', type: 'sys' }])} className="text-xs text-red-400/60 hover:text-red-400 px-2 py-1 rounded hover:bg-red-500/20">
              Clear
            </button>
            <button onClick={onClose} className="text-red-400/60 hover:text-red-400">
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-red-500/20 px-4 gap-1 bg-gray-900">
          {(['terminal', 'processes', 'system', 'files', 'analytics'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => {
                setActiveTab(tab);
                if (tab === 'system') fetchStats();
                if (tab === 'files') fetchExplorer(currentPath);
                if (tab === 'analytics') {
                  fetch(`${window.location.origin}/api/analytics`)
                    .then(r => r.json())
                    .then(setAnalytics);
                }
              }}
              className={`px-3 py-2 text-xs capitalize border-b-2 transition-colors ${
                activeTab === tab
                  ? 'border-red-500 text-red-400'
                  : 'border-transparent text-gray-400 hover:text-gray-300'
              }`}
            >
              {tab === 'terminal' && <Terminal size={12} className="inline mr-1" />}
              {tab === 'processes' && <Activity size={12} className="inline mr-1" />}
              {tab === 'system' && <Cpu size={12} className="inline mr-1" />}
              {tab === 'files' && <FolderOpen size={12} className="inline mr-1" />}
              {tab === 'analytics' && <BarChart3 size={12} className="inline mr-1" />}
              {tab}
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-hidden flex flex-col">
          {activeTab === 'terminal' && (
            <>
              <div className="flex-1 overflow-y-auto p-4 font-mono text-sm space-y-0.5">
                {lines.map((line, i) => (
                  <div
                    key={i}
                    className={`leading-relaxed whitespace-pre-wrap text-xs ${
                      line.type === 'in'
                        ? 'text-green-400'
                        : line.type === 'err'
                        ? 'text-red-400'
                        : line.type === 'sys'
                        ? 'text-yellow-400/70'
                        : 'text-gray-300'
                    }`}
                  >
                    {line.text}
                  </div>
                ))}
                {isRunning && <div className="text-red-400/60 animate-pulse">▌</div>}
                <div ref={endRef} />
              </div>
              <div className="border-t border-red-500/20 p-3 flex items-center gap-2 bg-gray-900">
                <span className="text-green-400 font-mono text-sm">$</span>
                <input
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter') runCommand();
                    if (e.key === 'ArrowUp') {
                      const i = Math.min(histIdx + 1, history.length - 1);
                      setHistIdx(i);
                      setInput(history[i] || '');
                    }
                    if (e.key === 'ArrowDown') {
                      const i = Math.max(histIdx - 1, -1);
                      setHistIdx(i);
                      setInput(i === -1 ? '' : history[i]);
                    }
                  }}
                  placeholder="Enter shell command..."
                  className="flex-1 bg-transparent text-white font-mono text-sm outline-none placeholder-gray-600"
                  autoFocus
                />
                <button
                  onClick={runCommand}
                  disabled={!input.trim() || isRunning}
                  className="px-3 py-1.5 bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white rounded text-xs flex items-center gap-1"
                >
                  <Play size={12} /> Run
                </button>
              </div>
            </>
          )}

          {activeTab === 'processes' && (
            <div className="p-4 overflow-y-auto">
              {processes.length === 0 ? (
                <p className="text-gray-500 text-sm">No active processes</p>
              ) : (
                <div className="space-y-2">
                  {processes.map((proc: any, i: number) => (
                    <div
                      key={i}
                      className="bg-gray-900 border border-red-500/20 rounded-lg p-3 flex items-center justify-between"
                    >
                      <div className="text-sm">
                        <p className="text-white font-mono">PID: {proc.pid}</p>
                        <p className="text-xs text-gray-400">ID: {proc.id}</p>
                        <p className={`text-xs font-semibold ${proc.status === 'running' ? 'text-green-400' : 'text-gray-400'}`}>
                          {proc.status}
                        </p>
                      </div>
                      {proc.status === 'running' && (
                        <button
                          onClick={() => killProcess(proc.id)}
                          className="px-3 py-1.5 bg-red-600/30 hover:bg-red-600 text-red-400 hover:text-white rounded text-xs transition-colors"
                        >
                          Kill
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'system' && (
            <div className="p-4 overflow-y-auto space-y-4">
              {systemStats ? (
                <>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-gray-900 border border-red-500/20 rounded-lg p-3">
                      <p className="text-xs text-gray-400 uppercase">Platform</p>
                      <p className="text-sm text-white font-semibold">{systemStats.platform}</p>
                    </div>
                    <div className="bg-gray-900 border border-red-500/20 rounded-lg p-3">
                      <p className="text-xs text-gray-400 uppercase">Uptime</p>
                      <p className="text-sm text-white font-semibold">{Math.round(systemStats.uptime / 3600)}h {Math.round((systemStats.uptime % 3600) / 60)}m</p>
                    </div>
                    <div className="bg-gray-900 border border-red-500/20 rounded-lg p-3">
                      <p className="text-xs text-gray-400 uppercase">Memory</p>
                      <p className="text-sm text-white font-semibold">{systemStats.memoryUsed}/{systemStats.memoryTotal} MB</p>
                      <div className="w-full bg-gray-800 rounded-full h-1.5 mt-1 overflow-hidden">
                        <div
                          className="bg-red-500 h-full"
                          style={{ width: `${systemStats.memoryPercent}%` }}
                        />
                      </div>
                    </div>
                    <div className="bg-gray-900 border border-red-500/20 rounded-lg p-3">
                      <p className="text-xs text-gray-400 uppercase">CPUs</p>
                      <p className="text-sm text-white font-semibold">{systemStats.cpuCount} × {systemStats.cpuModel}</p>
                    </div>
                  </div>
                </>
              ) : (
                <p className="text-gray-500 text-sm">Loading system stats...</p>
              )}
            </div>
          )}

          {activeTab === 'files' && (
            <div className="p-4 overflow-y-auto">
              <p className="text-xs text-gray-400 mb-3">Current: {currentPath}</p>
              {fileExplorer?.items ? (
                <div className="space-y-1">
                  {fileExplorer.items.map((item: any, i: number) => (
                    <button
                      key={i}
                      onClick={() => item.type === 'dir' && fetchExplorer(item.path)}
                      className={`w-full text-left px-3 py-2 rounded text-sm ${
                        item.type === 'dir'
                          ? 'bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 cursor-pointer'
                          : 'bg-gray-800/50 text-gray-300'
                      }`}
                    >
                      {item.type === 'dir' ? '📁' : '📄'} {item.name} {item.type === 'file' && `(${Math.round(item.size / 1024)}KB)`}
                    </button>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-sm">Loading files...</p>
              )}
            </div>
          )}

          {activeTab === 'analytics' && (
            <div className="p-4 overflow-y-auto space-y-4">
              {analytics ? (
                <>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-gray-900 border border-red-500/20 rounded-lg p-3">
                      <p className="text-xs text-gray-400 uppercase">Uptime</p>
                      <p className="text-sm text-white font-semibold">{analytics.uptime}s</p>
                    </div>
                    <div className="bg-gray-900 border border-red-500/20 rounded-lg p-3">
                      <p className="text-xs text-gray-400 uppercase">Commands Executed</p>
                      <p className="text-sm text-white font-semibold">{analytics.commands?.length || 0}</p>
                    </div>
                    <div className="bg-gray-900 border border-red-500/20 rounded-lg p-3">
                      <p className="text-xs text-gray-400 uppercase">Files Created</p>
                      <p className="text-sm text-white font-semibold">{analytics.filesCreated}</p>
                    </div>
                    <div className="bg-gray-900 border border-red-500/20 rounded-lg p-3">
                      <p className="text-xs text-gray-400 uppercase">Files Modified</p>
                      <p className="text-sm text-white font-semibold">{analytics.filesModified}</p>
                    </div>
                    <div className="bg-gray-900 border border-red-500/20 rounded-lg p-3 col-span-2">
                      <p className="text-xs text-gray-400 uppercase">Avg Cmd/Min</p>
                      <p className="text-sm text-white font-semibold">{analytics.avgCommandsPerMinute}</p>
                    </div>
                  </div>
                </>
              ) : (
                <p className="text-gray-500 text-sm">Loading analytics...</p>
              )}
            </div>
          )}
        </div>

        {/* Branding Watermark */}
        <div className="border-t border-red-500/20 px-4 py-2 bg-gray-900/50 text-center">
          <p className="text-xs text-red-400/50">
            🐛 WormGPT Enhanced • Terminal Control • Process Monitoring • System Stats • File Explorer • Analytics
          </p>
          <p className="text-xs text-red-400/40 mt-1">
            Made by <a href="https://t.me/FreeWormgpt" target="_blank" rel="noopener noreferrer" className="text-red-400 hover:text-red-300 underline">@FreeWormgpt</a>
          </p>
        </div>
      </div>
    </div>
  );
};
