@echo off
setlocal enabledelayedexpansion
title WormGPT Enhanced - Installer

echo.
echo  ===========================================
echo   WormGPT Enhanced - Windows 11 Installer
echo  ===========================================
echo.

:: Check Node.js
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] Node.js not found!
    echo  Please install Node.js 18+ from: https://nodejs.org
    echo  Then re-run this installer.
    pause
    exit /b 1
)

for /f "tokens=1 delims=v." %%a in ('node -v') do set NODE_MAJOR=%%a
for /f "tokens=2 delims=v." %%a in ('node -v') do set NODE_MAJOR=%%a
node -e "process.exit(parseInt(process.version.slice(1)) < 18 ? 1 : 0)"
if %errorlevel% neq 0 (
    echo  [ERROR] Node.js 18+ is required.
    echo  Your version: 
    node -v
    echo  Download: https://nodejs.org
    pause
    exit /b 1
)
echo  [OK] Node.js found:
node -v

:: Check Ollama
where ollama >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  [INFO] Ollama not found.
    echo  Please install Ollama for Windows from: https://ollama.com/download/windows
    echo.
    echo  After installing Ollama, re-run this installer.
    echo  Opening download page...
    start https://ollama.com/download/windows
    pause
    exit /b 1
) else (
    echo  [OK] Ollama found
)

:: Start Ollama in background
echo.
echo  [INFO] Starting Ollama service...
start /B "" ollama serve >nul 2>&1
timeout /t 3 /nobreak >nul

:: Pull model
echo  [INFO] Pulling model: godmoded/llama3-lexi-uncensored
echo  (This may take several minutes on first run - model is ~4GB)
echo.
ollama pull godmoded/llama3-lexi-uncensored
if %errorlevel% neq 0 (
    echo  [WARN] Model pull failed. You can pull it later with:
    echo         ollama pull godmoded/llama3-lexi-uncensored
)

:: Install frontend dependencies
echo.
echo  [INFO] Installing frontend dependencies...
cd app
call npm install
if %errorlevel% neq 0 (
    echo  [ERROR] Frontend npm install failed.
    pause
    exit /b 1
)
echo  [OK] Frontend dependencies installed

:: Build frontend
echo.
echo  [INFO] Building frontend...
call npm run build
if %errorlevel% neq 0 (
    echo  [ERROR] Frontend build failed. See error above.
    pause
    exit /b 1
)
echo  [OK] Frontend built successfully

:: Install server dependencies
echo.
echo  [INFO] Installing server dependencies...
cd ..\server
call npm install
if %errorlevel% neq 0 (
    echo  [ERROR] Server npm install failed.
    pause
    exit /b 1
)
echo  [OK] Server dependencies installed

cd ..

echo.
echo  ===========================================
echo   Installation Complete!
echo  ===========================================
echo.
echo   To start WormGPT, double-click: start.bat
echo   Or run in terminal:  start.bat
echo.
echo   Then open your browser to: http://localhost:3001
echo   Password: Realnojokepplwazy1234
echo.
pause
