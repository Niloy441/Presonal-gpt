import express from 'express';
import cors from 'cors';
import { exec, spawn } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import os from 'os';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import multer from 'multer';
import AdmZip from 'adm-zip';
import { fileURLToPath } from 'url';
import simpleGit from 'simple-git';

const execAsync = promisify(exec);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const httpServer = createServer(app);
const wss = new WebSocketServer({ server: httpServer });
const isWin = process.platform === 'win32';

app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '50mb' }));
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 100 * 1024 * 1024 } });

// ─── Enhanced State Management ────────────────────────────────────────────────
const processPool = new Map(); // Track active processes
const sessionAnalytics = {
  startTime: Date.now(),
  commands: [],
  filesCreated: 0,
  filesModified: 0,
  terminalSessions: 0,
};

// ─── Helper: spawn a shell command cross-platform
function spawnShell(command, cwd) {
  if (isWin) {
    return spawn('cmd', ['/c', command], { cwd, env: process.env, shell: false });
  } else {
    return spawn('sh', ['-c', command], { cwd, env: process.env });
  }
}

// ─── Enhanced Helper: Get process info (CPU, memory, status)
async function getProcessStats() {
  try {
    const cmd = isWin 
      ? 'tasklist /fo csv /nh' 
      : 'ps aux';
    const { stdout } = await execAsync(cmd);
    return stdout;
  } catch (e) {
    return 'Unable to fetch process list';
  }
}

// ─── Enhanced Helper: Get system resource usage
async function getSystemStats() {
  const cpus = os.cpus();
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMem = totalMem - freeMem;
  
  return {
    cpuCount: cpus.length,
    cpuModel: cpus[0]?.model || 'Unknown',
    memoryUsed: Math.round(usedMem / 1024 / 1024),
    memoryTotal: Math.round(totalMem / 1024 / 1024),
    memoryPercent: Math.round((usedMem / totalMem) * 100),
    platform: os.platform(),
    uptime: Math.round(os.uptime()),
    loadAverage: os.loadavg(),
  };
}

// ─── Enhanced Helper: File system explorer with metadata
async function exploreDirectory(dirPath, maxDepth = 2, currentDepth = 0) {
  try {
    const entries = await fsp.readdir(dirPath, { withFileTypes: true });
    const items = [];
    
    for (const entry of entries) {
      if (entry.name.startsWith('.')) continue; // Skip hidden files
      const fullPath = path.join(dirPath, entry.name);
      const stat = await fsp.stat(fullPath);
      
      items.push({
        name: entry.name,
        type: entry.isDirectory() ? 'dir' : 'file',
        path: fullPath,
        size: stat.size,
        modified: new Date(stat.mtime).toISOString(),
        isReadable: true,
        children: entry.isDirectory() && currentDepth < maxDepth 
          ? await exploreDirectory(fullPath, maxDepth, currentDepth + 1)
          : undefined,
      });
    }
    
    return items;
  } catch (e) {
    return [];
  }
}

// ─── Enhanced Helper: Parse terminal output for errors/warnings
function parseTerminalOutput(output) {
  const lines = output.split('\n');
  const errors = [];
  const warnings = [];
  
  lines.forEach(line => {
    if (line.toLowerCase().includes('error') || line.toLowerCase().includes('fatal')) {
      errors.push(line);
    } else if (line.toLowerCase().includes('warn')) {
      warnings.push(line);
    }
  });
  
  return { errors, warnings, rawLines: lines.length };
}

// ─── WebSocket: Enhanced terminal with multiplexing & monitoring ─────────────
wss.on('connection', (ws) => {
  const sessionId = Math.random().toString(36).slice(2);
  const processes = new Map(); // Per-session process pool
  let currentCwd = os.homedir();
  
  sessionAnalytics.terminalSessions++;

  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw.toString());
      const { type, code, lang, command, cwd, processId, signal } = msg;

      // ─── Run Code (Python, JS, Bash) ───────────────────────────────────
      if (type === 'run_code') {
        const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'wgpt-'));
        let filename, runCmd;

        if (lang === 'python' || lang === 'py') {
          filename = path.join(tmpDir, 'main.py');
          fs.writeFileSync(filename, code);
          runCmd = isWin ? `python "${filename}"` : `python3 "${filename}"`;
        } else if (lang === 'javascript' || lang === 'js') {
          filename = path.join(tmpDir, 'main.js');
          fs.writeFileSync(filename, code);
          runCmd = `node "${filename}"`;
        } else if (lang === 'bash' || lang === 'sh') {
          if (isWin) {
            filename = path.join(tmpDir, 'main.bat');
            fs.writeFileSync(filename, code);
            runCmd = `cmd /c "${filename}"`;
          } else {
            filename = path.join(tmpDir, 'main.sh');
            fs.writeFileSync(filename, code);
            runCmd = `bash "${filename}"`;
          }
        } else {
          ws.send(JSON.stringify({ type: 'stderr', data: 'Unsupported language: ' + lang }));
          ws.send(JSON.stringify({ type: 'exit', code: 1 }));
          return;
        }

        const proc = spawnShell(runCmd, tmpDir);
        const procId = Math.random().toString(36).slice(2);
        processes.set(procId, proc);
        
        let stdout = '';
        let stderr = '';

        ws.send(JSON.stringify({ type: 'start', processId: procId }));
        
        proc.stdout.on('data', d => {
          stdout += d.toString();
          ws.send(JSON.stringify({ type: 'stdout', data: d.toString(), processId: procId }));
        });
        
        proc.stderr.on('data', d => {
          stderr += d.toString();
          ws.send(JSON.stringify({ type: 'stderr', data: d.toString(), processId: procId }));
        });
        
        proc.on('close', code => {
          const analysis = parseTerminalOutput(stdout + stderr);
          ws.send(JSON.stringify({ 
            type: 'exit', 
            code,
            processId: procId,
            analysis,
          }));
          processes.delete(procId);
          try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
        });
      }

      // ─── Shell Command with Working Directory ──────────────────────────
      else if (type === 'shell') {
        const workDir = cwd || currentCwd;
        currentCwd = workDir; // Remember for next command
        
        const proc = spawnShell(command, workDir);
        const procId = Math.random().toString(36).slice(2);
        processes.set(procId, proc);
        
        let stdout = '';
        let stderr = '';
        
        sessionAnalytics.commands.push({
          command,
          timestamp: new Date().toISOString(),
          cwd: workDir,
        });

        proc.stdout.on('data', d => {
          stdout += d.toString();
          ws.send(JSON.stringify({ type: 'stdout', data: d.toString(), processId: procId }));
        });
        
        proc.stderr.on('data', d => {
          stderr += d.toString();
          ws.send(JSON.stringify({ type: 'stderr', data: d.toString(), processId: procId }));
        });
        
        proc.on('close', code => {
          const analysis = parseTerminalOutput(stdout + stderr);
          ws.send(JSON.stringify({ 
            type: 'exit', 
            code,
            processId: procId,
            analysis,
            currentCwd: workDir,
          }));
          processes.delete(procId);
        });
      }

      // ─── Kill specific process ─────────────────────────────────────────
      else if (type === 'kill') {
        const proc = processes.get(processId);
        if (proc) {
          if (isWin) {
            try { exec(`taskkill /pid ${proc.pid} /T /F`); } catch {}
          } else {
            proc.kill(signal || 'SIGTERM');
          }
          processes.delete(processId);
          ws.send(JSON.stringify({ type: 'process_killed', processId }));
        }
      }

      // ─── List active processes ─────────────────────────────────────────
      else if (type === 'list_processes') {
        const procs = Array.from(processes.entries()).map(([id, p]) => ({
          id,
          pid: p.pid,
          status: p.killed ? 'killed' : 'running',
        }));
        ws.send(JSON.stringify({ type: 'processes', data: procs }));
      }

      // ─── Get system stats ──────────────────────────────────────────────
      else if (type === 'system_stats') {
        getSystemStats().then(stats => {
          ws.send(JSON.stringify({ type: 'system_stats', data: stats }));
        });
      }

      // ─── Get process info ──────────────────────────────────────────────
      else if (type === 'process_stats') {
        getProcessStats().then(stats => {
          ws.send(JSON.stringify({ type: 'process_stats', data: stats }));
        });
      }

    } catch (e) {
      ws.send(JSON.stringify({ type: 'stderr', data: 'Error: ' + e.message }));
    }
  });

  ws.on('close', () => {
    // Clean up all processes when connection closes
    for (const [, proc] of processes) {
      if (!proc.killed) proc.kill();
    }
  });
});

// ─── REST API: Enhanced file operations ────────────────────────────────────
app.post('/api/chat', async (req, res) => {
  const { messages, model, temperature, stream, ollamaUrl } = req.body;
  const base = ollamaUrl || 'http://localhost:11434';
  try {
    const resp = await fetch(`${base}/api/chat`, {
      method: 'POST', 
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        model: model || 'godmoded/llama3-lexi-uncensored', 
        messages, 
        temperature: temperature ?? 0.7, 
        stream: stream !== false 
      }),
    });
    if (!resp.ok) { res.status(resp.status).json({ error: await resp.text() }); return; }
    if (stream !== false) {
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      while (true) {
        const { done, value } = await reader.read();
        if (done) { res.write('data: [DONE]\n\n'); res.end(); break; }
        const text = decoder.decode(value);
        for (const line of text.split('\n').filter(l => l.trim())) {
          try { 
            const json = JSON.parse(line); 
            res.write(`data: ${JSON.stringify(json)}\n\n`); 
            if (json.done) { res.end(); return; } 
          } catch {}
        }
      }
    } else { res.json(await resp.json()); }
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── File system explorer ──────────────────────────────────────────────────
app.get('/api/fs/explore', async (req, res) => {
  try {
    const dirPath = req.query.path || os.homedir();
    const maxDepth = parseInt(req.query.depth || '2');
    const items = await exploreDirectory(dirPath, maxDepth);
    res.json({ path: dirPath, items });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── Read file with syntax detection ───────────────────────────────────────
app.get('/api/fs/read', async (req, res) => {
  try {
    const filePath = req.query.path;
    if (!filePath) throw new Error('No path provided');
    
    const stat = await fsp.stat(filePath);
    if (stat.size > 10 * 1024 * 1024) {
      res.json({ error: 'File too large', size: stat.size });
      return;
    }

    const content = await fsp.readFile(filePath, 'utf8');
    const ext = path.extname(filePath);
    res.json({ path: filePath, content, ext, size: stat.size });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── Write file with tracking ──────────────────────────────────────────────
app.post('/api/fs/write', async (req, res) => {
  try {
    const { path: filePath, content } = req.body;
    if (!filePath) throw new Error('No path provided');
    
    const exists = fs.existsSync(filePath);
    await fsp.writeFile(filePath, content, 'utf8');
    
    if (exists) sessionAnalytics.filesModified++;
    else sessionAnalytics.filesCreated++;
    
    res.json({ ok: true, isNew: !exists });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── Directory operations ──────────────────────────────────────────────────
app.post('/api/fs/mkdir', async (req, res) => {
  try {
    const dirPath = req.body.path;
    await fsp.mkdir(dirPath, { recursive: true });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/fs/delete', async (req, res) => {
  try {
    const itemPath = req.body.path;
    const stat = await fsp.stat(itemPath);
    if (stat.isDirectory()) {
      await fsp.rm(itemPath, { recursive: true, force: true });
    } else {
      await fsp.unlink(itemPath);
    }
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── Ollama endpoints ──────────────────────────────────────────────────────
app.get('/api/ollama/status', async (req, res) => {
  const base = req.query.url || 'http://localhost:11434';
  try { const r = await fetch(`${base}/api/tags`); res.json({ connected: r.ok }); } catch { res.json({ connected: false }); }
});

app.get('/api/ollama/models', async (req, res) => {
  const base = req.query.url || 'http://localhost:11434';
  try { const r = await fetch(`${base}/api/tags`); if (!r.ok) throw new Error('Not reachable'); res.json(await r.json()); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── System monitoring ─────────────────────────────────────────────────────
app.get('/api/system/stats', async (req, res) => {
  try {
    const stats = await getSystemStats();
    res.json(stats);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/system/processes', async (req, res) => {
  try {
    const stats = await getProcessStats();
    res.json({ processes: stats });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── Analytics endpoint ───────────────────────────────────────────────────
app.get('/api/analytics', (req, res) => {
  const uptime = Math.round((Date.now() - sessionAnalytics.startTime) / 1000);
  res.json({
    ...sessionAnalytics,
    uptime,
    avgCommandsPerMinute: uptime > 0 ? (sessionAnalytics.commands.length / (uptime / 60)).toFixed(2) : 0,
  });
});

// ─── Project upload ───────────────────────────────────────────────────────
app.post('/api/project/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) { res.status(400).json({ error: 'No file' }); return; }
    const TEXT_EXTS = ['.js','.ts','.tsx','.jsx','.py','.html','.css','.json','.md','.txt','.sh','.yaml','.yml','.toml','.rs','.go','.java','.cpp','.c','.h','.sql'];
    let files = [];
    if (req.file.originalname.endsWith('.zip')) {
      const zip = new AdmZip(req.file.buffer);
      for (const e of zip.getEntries()) {
        if (!e.isDirectory) {
          const ext = path.extname(e.entryName).toLowerCase();
          const isText = TEXT_EXTS.includes(ext) || !ext;
          files.push({ name: e.entryName, content: isText ? e.getData().toString('utf8') : `[binary: ${ext}]`, type: isText ? 'text' : 'binary' });
        }
      }
    } else {
      files = [{ name: req.file.originalname, content: req.file.buffer.toString('utf8'), type: 'text' }];
    }
    res.json({ files });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Git operations ───────────────────────────────────────────────────────
const gitR = (p) => simpleGit(p || process.cwd());
app.post('/api/git/status', async (req, res) => { try { res.json({ status: await gitR(req.body.repoPath).status() }); } catch(e) { res.status(500).json({ error: e.message }); } });
app.post('/api/git/diff', async (req, res) => { try { res.json({ diff: req.body.file ? await gitR(req.body.repoPath).diff([req.body.file]) : await gitR(req.body.repoPath).diff() }); } catch(e) { res.status(500).json({ error: e.message }); } });
app.post('/api/git/commit', async (req, res) => {
  try {
    const git = gitR(req.body.repoPath);
    if (req.body.files?.length) await git.add(req.body.files); else await git.add('.');
    res.json({ result: await git.commit(req.body.message || 'WormGPT commit') });
  } catch(e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/git/branch', async (req, res) => { try { await gitR(req.body.repoPath).checkoutLocalBranch(req.body.name); res.json({ success: true }); } catch(e) { res.status(500).json({ error: e.message }); } });

// ─── Static files ─────────────────────────────────────────────────────────
const distPath = path.join(__dirname, '..', 'app', 'dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get('*', (_, res) => res.sendFile(path.join(distPath, 'index.html')));
}

const PORT = process.env.PORT || 3001;
httpServer.listen(PORT, () => {
  console.log(`\n 🐛 WormGPT Enhanced Server running at http://localhost:${PORT}`);
  console.log(` WebSocket at ws://localhost:${PORT}`);
  console.log(` Password: Realnojokepplwazy1234\n`);
  console.log(` ✨ New Features:`);
  console.log(`    • Process multiplexing`);
  console.log(`    • System monitoring`);
  console.log(`    • File explorer`);
  console.log(`    • Error/warning parsing`);
  console.log(`    • Analytics tracking\n`);
});
