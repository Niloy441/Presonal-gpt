#!/bin/bash

# WormGPT Enhanced - Quick Start Script
# This script sets up and runs the enhanced version

set -e

echo "🐛 WormGPT Enhanced - Setup Script"
echo "=================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js is not installed. Please install Node.js 18+${NC}"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo -e "${RED}❌ Node.js 18+ required. You have: $(node -v)${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Node.js $(node -v) detected${NC}"
echo ""

# Install backend dependencies
echo -e "${YELLOW}📦 Installing server dependencies...${NC}"
cd server
npm install
cd ..

# Build frontend
echo -e "${YELLOW}📦 Building frontend...${NC}"
cd app
npm install
npm run build
cd ..

echo ""
echo -e "${GREEN}✅ Setup complete!${NC}"
echo ""
echo -e "${YELLOW}Starting WormGPT Enhanced...${NC}"
echo ""

# Start server
cd server
echo -e "${GREEN}🚀 Server starting on http://localhost:3001${NC}"
echo -e "${GREEN}🔐 Password: Realnojokepplwazy1234${NC}"
echo ""
echo -e "${YELLOW}Opening in browser...${NC}"

# Try to open browser
if command -v xdg-open &> /dev/null; then
    xdg-open http://localhost:3001
elif command -v open &> /dev/null; then
    open http://localhost:3001
fi

echo ""
echo -e "${GREEN}✨ Features Enabled:${NC}"
echo "   • Process Multiplexing - Run multiple commands in parallel"
echo "   • System Monitoring - Real-time CPU/memory stats"
echo "   • File Explorer - Browse and manage files"
echo "   • Error Detection - Automatic error/warning parsing"
echo "   • Analytics - Track usage and metrics"
echo "   • Prominent Branding - @FreeWormgpt attribution"
echo ""

# Start server
npm start
